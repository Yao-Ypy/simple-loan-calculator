package th.ac.su.yaowaluk.simpleloancalculator.data

data class SimpleLoan(
    val promo_name: String,
    val promo_description: String,
    val promo_code: Int,
    val imageFile: String

)