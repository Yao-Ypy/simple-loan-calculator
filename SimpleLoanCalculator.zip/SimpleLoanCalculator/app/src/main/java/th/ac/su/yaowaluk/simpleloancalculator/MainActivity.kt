package th.ac.su.yaowaluk.simpleloancalculator

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_detail.*
import th.ac.su.yaowaluk.simpleloancalculator.Utils.getJsonDataFromAsset
import th.ac.su.yaowaluk.simpleloancalculator.data.SimpleLoan
import th.ac.su.yaowaluk.simpleloancalculator.data.SimpleLoanAdapter

class MainActivity : AppCompatActivity() {

//    lateinit var edtNumber1 : EditText
//    lateinit var edtNumber2 : EditText
//    lateinit var edtNumber3 : EditText


    var itemList: java.util.ArrayList<SimpleLoan> = java.util.ArrayList<SimpleLoan>()
    lateinit var arrayAdapter: ArrayAdapter<SimpleLoan>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        edtNumber1 = findViewById<EditText>(R.id.edtNumber1)
//        edtNumber2 = findViewById<EditText>(R.id.edtNumber2)
//        edtNumber3 = findViewById<EditText>(R.id.edtNumber3)
//
            var intent = Intent(this@MainActivity. ResultActivity::class.java)

            val jsonFileString = getJsonDataFromAsset(applicationContext, "promotion.json")

            val gson = Gson()
            val listItemType = object : TypeToken<ArrayList<SimpleLoan>>() {}.type

            var SimpleList: ArrayList<SimpleLoan> = gson.fromJson(jsonFileString, listItemType)

            itemList = SimpleList
            val adapter = SimpleLoanAdapter(this@MainActivity, itemList)

        val okBtn = findViewById<Button>(R.id.btnOK);
        okBtn.setOnClickListener {
            var intent = Intent()
            setResult(Activity.RESULT_OK,intent)
            finish()
//
//        listView.adapter = adapter
//
//        listView.setOnItemClickListener { parent, view, position, id ->
//
//            var intent = Intent(this@MainActivity, DetailActivity::class.java)
//
//            intent.putExtra("title", itemList[position].promo_name)
//            intent.putExtra("caption", itemList[position].promo_description)
//            intent.putExtra("coding", itemList[position].promo_code)
//            intent.putExtra("imageFile", itemList[position].imageFile)
//
//            startActivity(intent)


        }
    }
}

