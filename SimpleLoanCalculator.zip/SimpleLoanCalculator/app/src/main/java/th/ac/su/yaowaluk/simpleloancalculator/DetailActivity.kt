package th.ac.su.yaowaluk.simpleloancalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.list_item_simple.*

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

//        val title = intent.getStringExtra("title")
//        val caption = intent.getStringExtra("caption")
//        val coding = intent.getStringExtra("coding")
//
//
//        tvName.setText(title)
//        tvCodename.setText(coding)
//        tvDescriptionname.setText(caption)


    }
}